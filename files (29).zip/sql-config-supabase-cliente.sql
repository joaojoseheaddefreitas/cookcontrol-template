-- ═══════════════════════════════════════════════════════════════════════
-- COOKCONTROL — REGISTRO DO SUPABASE PRÓPRIO DE CADA CLIENTE
-- Rodar no SQL Editor do Supabase do BACKEND DE PAGAMENTOS (nortxaigbrzuviyaomck)
-- ═══════════════════════════════════════════════════════════════════════
--
-- Por quê: cada restaurante pode ter seu PRÓPRIO projeto Supabase pro
-- cardápio/pedidos (não necessariamente o mesmo do backend de pagamentos).
-- Essa tabela guarda, pra cada empresa_id, qual é o Supabase de verdade
-- daquele restaurante, pra o backend de pagamentos saber ONDE marcar o
-- pedido como "pago" na hora do webhook.
--
-- Não precisa cifrar a chave aqui: é a "anon key" pública, a mesma que já
-- fica visível dentro do próprio HTML do restaurante — não é segredo.

CREATE TABLE IF NOT EXISTS config_supabase_cliente (
  empresa_id          TEXT PRIMARY KEY,
  supabase_url        TEXT NOT NULL,
  supabase_anon_key   TEXT NOT NULL,
  criado_em           TIMESTAMPTZ NOT NULL DEFAULT now(),
  atualizado_em       TIMESTAMPTZ NOT NULL DEFAULT now()
);
