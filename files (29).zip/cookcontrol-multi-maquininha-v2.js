/**
 * ═══════════════════════════════════════════════════════════════════════
 * COOKCONTROL — API MULTI-MAQUININHA (4 MARCAS SIMULTÂNEAS NO SALÃO)
 * ═══════════════════════════════════════════════════════════════════════
 *
 * Cenário real: 4 maquininhas Smart POS Android (Mercado Pago, PagBank,
 * Cielo, Stone) ligadas ao mesmo tempo no salão, cada uma rodando o app
 * CookControl. Não existe impressora de rede — cada maquininha imprime na
 * própria bobina, usando o texto que este servidor devolve pronto.
 *
 * STATUS REAL DE CADA MARCA (não mudou nas versões anteriores desta
 * conversa — resumindo pra não repetir a explicação longa de novo):
 *   mercadopago → testConnection, Pix e push por serial: FUNCIONAL (api.mercadopago.com)
 *   cielo       → testConnection e Pix: FUNCIONAL (api.cieloecommerce.cielo.com.br).
 *                 Push físico LIO: endpoint exato pendente de confirmação
 *                 na sua conta (ver TODO_CONFIRMAR).
 *   pagbank     → testConnection e Pix: FUNCIONAL (api.pagbank.com.br).
 *                 Cartão físico: devolve comando local (ACIONAR_LEITOR_LOCAL),
 *                 porque o push por servidor não existe nessa marca — quem
 *                 aciona é o próprio app dentro da Moderninha (PlugPag).
 *   stone       → sem endpoint self-service público. Lança erro explícito.
 * ═══════════════════════════════════════════════════════════════════════
 */

'use strict';

const express = require('express');
const https = require('https');
const crypto = require('crypto');
const { createClient } = require('@supabase/supabase-js');

const router = express.Router();
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

/**
 * Cada restaurante pode ter seu PRÓPRIO Supabase (cardápio/pedidos), fora
 * do Supabase deste backend de pagamentos. Essa função busca, se existir,
 * o Supabase real daquele restaurante — e cai no banco padrão (deste
 * backend) se o restaurante ainda não registrou um separado.
 */
async function getSupabaseDoCliente(empresaId) {
  const { data } = await supabase
    .from('config_supabase_cliente')
    .select('*')
    .eq('empresa_id', empresaId)
    .single();

  if (data?.supabase_url && data?.supabase_anon_key) {
    return createClient(data.supabase_url, data.supabase_anon_key);
  }
  // Sem registro próprio: assume que este restaurante usa o mesmo banco
  // do backend de pagamentos (ex: Barraca Sol da Bahia).
  return supabase;
}

// ─────────────────────────────────────────────────────────────────────────
// 1. CIFRA — credentials guardadas como um único JSONB cifrado por linha
// ─────────────────────────────────────────────────────────────────────────

const MASTER_KEY_HEX = process.env.COOKCONTROL_MASTER_KEY;
if (!MASTER_KEY_HEX || MASTER_KEY_HEX.length !== 64) {
  throw new Error(
    'Defina COOKCONTROL_MASTER_KEY (64 hex/32 bytes). Gere com: node -e ' +
    `"console.log(require('crypto').randomBytes(32).toString('hex'))"`
  );
}
const MASTER_KEY = Buffer.from(MASTER_KEY_HEX, 'hex');

function cifrarCredentials(credentialsObj) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', MASTER_KEY, iv);
  const cifrado = Buffer.concat([cipher.update(JSON.stringify(credentialsObj), 'utf8'), cipher.final()]);
  // Guardado como um único objeto JSONB — exatamente como pedido.
  return {
    cifrado: cifrado.toString('base64'),
    iv: iv.toString('base64'),
    authtag: cipher.getAuthTag().toString('base64'),
  };
}

function decifrarCredentials(credentialsJsonb) {
  const { cifrado, iv, authtag } = credentialsJsonb;
  const decipher = crypto.createDecipheriv('aes-256-gcm', MASTER_KEY, Buffer.from(iv, 'base64'));
  decipher.setAuthTag(Buffer.from(authtag, 'base64'));
  const decifrado = Buffer.concat([decipher.update(Buffer.from(cifrado, 'base64')), decipher.final()]);
  return JSON.parse(decifrado.toString('utf8'));
}

// ─────────────────────────────────────────────────────────────────────────
// 2. HTTP HELPER + ENDPOINTS REAIS DE PRODUÇÃO
// ─────────────────────────────────────────────────────────────────────────

function httpRequest(method, url, headers, bodyObj) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = bodyObj ? JSON.stringify(bodyObj) : null;
    const req = https.request(
      { method, hostname: u.hostname, path: u.pathname + u.search, port: 443,
        headers: { 'Content-Type': 'application/json', ...(body ? { 'Content-Length': Buffer.byteLength(body) } : {}), ...headers },
        timeout: 15000 },
      (res) => {
        let raw = '';
        res.on('data', (c) => (raw += c));
        res.on('end', () => {
          let parsed;
          try { parsed = raw ? JSON.parse(raw) : {}; } catch (e) { parsed = { rawBody: raw }; }
          resolve({ statusCode: res.statusCode, body: parsed });
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error(`Timeout ao chamar ${url}`)));
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

const ENDPOINTS = {
  mercadopago: {
    base: 'https://api.mercadopago.com',
    devices: '/point/integration-api/devices',
    paymentIntentByDevice: (serialNumber) => `/v1/point/integration-api/payment-intents/device/${serialNumber}`,
    createPayment: '/v1/payments',
    getPayment: (id) => `/v1/payments/${id}`,
  },
  cielo: {
    ecommerceBase: 'https://api.cieloecommerce.cielo.com.br',
    ecommerceQueryBase: 'https://apiquery.cieloecommerce.cielo.com.br',
    sales: '/1/sales/',
    salesQuery: (id) => `/1/sales/${id}`,
    // TODO_CONFIRMAR: endpoint LIO Order Manager real da conta —
    // https://developercielo.github.io/manual/cielo-lio
    lioOrdersBase: 'https://TODO_CONFIRMAR.cielo.com.br',
  },
  pagbank: {
    base: 'https://api.pagbank.com.br',
    orders: '/orders',
    getOrder: (id) => `/orders/${id}`,
  },
};

class StoneNotHomologadoError extends Error {
  constructor() {
    super('Stone exige homologação como parceiro (Programa de Parcerias) — não há endpoint self-service público.');
    this.name = 'StoneNotHomologadoError';
  }
}
class ProviderNaoSuportadoError extends Error {
  constructor(p) { super(`Provider '${p}' não reconhecido.`); this.name = 'ProviderNaoSuportadoError'; }
}

// ─────────────────────────────────────────────────────────────────────────
// 3. TEXTO BRUTO PRA BOBINA DA PRÓPRIA MAQUININHA
// ─────────────────────────────────────────────────────────────────────────

function montarTextoConta(numeroMesa, itensPedido, valorTotal, orderId) {
  let t = `CONTA DA MESA ${String(numeroMesa).padStart(2, '0')}\nPedido: ${orderId}\n------------------------------\n`;
  for (const item of itensPedido) {
    t += `${item.quantidade || 1}x ${item.nome} .......... R$ ${Number(item.preco || 0).toFixed(2)}\n`;
  }
  return t + `------------------------------\nTOTAL: R$ ${Number(valorTotal).toFixed(2)}\n`;
}

function montarTextoCozinha(numeroMesa, itensPedido, orderId) {
  let t = `*** PRODUCAO — MESA ${String(numeroMesa).padStart(2, '0')} ***\nPedido: ${orderId}\n==============================\n`;
  for (const item of itensPedido) {
    t += `${item.quantidade || 1}x ${(item.nome || '').toUpperCase()}\n`;
    if (item.observacao) t += `   obs: ${item.observacao}\n`;
  }
  return t + '==============================\n';
}

// ─────────────────────────────────────────────────────────────────────────
// 4. ADAPTERS POR PROVIDER
// ─────────────────────────────────────────────────────────────────────────

const adapters = {
  mercadopago: {
    async testConnection(credentials) {
      const resp = await httpRequest('GET', ENDPOINTS.mercadopago.base + ENDPOINTS.mercadopago.devices,
        { Authorization: `Bearer ${credentials.accessToken}` });
      return resp.statusCode === 200
        ? { conectado: true, dispositivos: resp.body.devices || resp.body }
        : { conectado: false, motivo: `Access Token inválido (HTTP ${resp.statusCode})` };
    },
    async criarPix(credentials, valorTotal, orderId) {
      const resp = await httpRequest('POST', ENDPOINTS.mercadopago.base + ENDPOINTS.mercadopago.createPayment,
        { Authorization: `Bearer ${credentials.accessToken}`, 'X-Idempotency-Key': `mesa-${orderId}-${Date.now()}` },
        { transaction_amount: Number(valorTotal), payment_method_id: 'pix', external_reference: String(orderId), payer: { email: 'cliente@cookcontrol.app' } });
      if (resp.statusCode >= 300) throw new Error(`Mercado Pago recusou Pix: HTTP ${resp.statusCode} — ${JSON.stringify(resp.body)}`);
      const tx = resp.body.point_of_interaction?.transaction_data || {};
      return { paymentId: resp.body.id, qrCode: tx.qr_code, qrCodeBase64: tx.qr_code_base64 };
    },
    async pushParaTerminal(credentials, serialNumber, valorTotal, orderId) {
      // Interpolação correta com template string, como pedido.
      const resp = await httpRequest('POST', ENDPOINTS.mercadopago.base + ENDPOINTS.mercadopago.paymentIntentByDevice(`${serialNumber}`),
        { Authorization: `Bearer ${credentials.accessToken}` },
        { amount: Math.round(Number(valorTotal) * 100), additional_info: { external_reference: String(orderId) } });
      if (resp.statusCode >= 300) throw new Error(`Mercado Pago recusou push pro terminal ${serialNumber}: HTTP ${resp.statusCode}`);
      return { comando: 'AGUARDANDO_CARTAO_NA_MAQUINA', paymentIntentId: resp.body.id, status: resp.body.state || 'ENVIADO' };
    },
    async consultarStatus(credentials, paymentId) {
      const resp = await httpRequest('GET', ENDPOINTS.mercadopago.base + ENDPOINTS.mercadopago.getPayment(paymentId),
        { Authorization: `Bearer ${credentials.accessToken}` });
      if (resp.statusCode !== 200) throw new Error(`Falha ao consultar pagamento ${paymentId} (HTTP ${resp.statusCode})`);
      return { statusOficial: resp.body.status, pago: resp.body.status === 'approved' };
    },
  },

  cielo: {
    async testConnection(credentials) {
      const resp = await httpRequest('GET', ENDPOINTS.cielo.ecommerceQueryBase + '/1/sales?merchantOrderId=cookcontrol-ping',
        { MerchantId: credentials.merchantId, MerchantKey: credentials.merchantKey });
      if (resp.statusCode === 401 || resp.statusCode === 403) return { conectado: false, motivo: 'MerchantId/MerchantKey inválidos.' };
      return { conectado: true };
    },
    async criarPix(credentials, valorTotal, orderId) {
      const resp = await httpRequest('POST', ENDPOINTS.cielo.ecommerceBase + ENDPOINTS.cielo.sales,
        { MerchantId: credentials.merchantId, MerchantKey: credentials.merchantKey },
        { MerchantOrderId: String(orderId), Payment: { Type: 'Pix', Amount: Math.round(Number(valorTotal) * 100) } });
      if (resp.statusCode >= 300) throw new Error(`Cielo recusou Pix: HTTP ${resp.statusCode}`);
      const p = resp.body.Payment || {};
      return { paymentId: p.PaymentId, qrCode: p.QrCodeString, qrCodeBase64: p.QrCodeBase64Image };
    },
    async pushParaTerminal(credentials, serialNumber, valorTotal, orderId) {
      if (ENDPOINTS.cielo.lioOrdersBase.includes('TODO_CONFIRMAR')) {
        return { comando: 'ACIONAR_LEITOR_LOCAL', motivo: 'Endpoint LIO Order Manager não confirmado — app local deve acionar o leitor da própria maquininha.', valorLocal: valorTotal };
      }
      const resp = await httpRequest('POST', ENDPOINTS.cielo.lioOrdersBase + '/orders',
        { MerchantId: credentials.merchantId, MerchantKey: credentials.merchantKey },
        { serialNumber, externalReference: String(orderId), amount: Math.round(Number(valorTotal) * 100) });
      if (resp.statusCode >= 300) throw new Error(`Cielo LIO recusou push pro terminal ${serialNumber}: HTTP ${resp.statusCode}`);
      return { comando: 'AGUARDANDO_CARTAO_NA_MAQUINA', orderId: resp.body.id || resp.body.orderId };
    },
    async consultarStatus(credentials, paymentId) {
      const resp = await httpRequest('GET', ENDPOINTS.cielo.ecommerceQueryBase + ENDPOINTS.cielo.salesQuery(paymentId),
        { MerchantId: credentials.merchantId, MerchantKey: credentials.merchantKey });
      if (resp.statusCode !== 200) throw new Error(`Falha ao consultar pagamento ${paymentId} na Cielo (HTTP ${resp.statusCode})`);
      const status = resp.body.Payment?.Status;
      return { statusOficial: status, pago: status === 2 };
    },
  },

  pagbank: {
    async testConnection(credentials) {
      const resp = await httpRequest('GET', ENDPOINTS.pagbank.base + '/orders?limit=1', { Authorization: `Bearer ${credentials.token}` });
      if (resp.statusCode === 401 || resp.statusCode === 403) return { conectado: false, motivo: 'Token PagBank inválido.' };
      return { conectado: true };
    },
    async criarPix(credentials, valorTotal, orderId) {
      const resp = await httpRequest('POST', ENDPOINTS.pagbank.base + ENDPOINTS.pagbank.orders, { Authorization: `Bearer ${credentials.token}` },
        { reference_id: String(orderId),
          customer: { name: 'Cliente Mesa', email: 'cliente@cookcontrol.app', tax_id: '00000000000' },
          items: [{ name: `Pedido ${orderId}`, quantity: 1, unit_amount: Math.round(Number(valorTotal) * 100) }],
          qr_codes: [{ amount: { value: Math.round(Number(valorTotal) * 100) } }] });
      if (resp.statusCode >= 300) throw new Error(`PagBank recusou Pix: HTTP ${resp.statusCode}`);
      const qr = (resp.body.qr_codes || [])[0] || {};
      return { paymentId: resp.body.id, qrCode: qr.text };
    },
    async pushParaTerminal(credentials, serialNumber, valorTotal) {
      // PagBank não expõe push remoto por serial via REST — PlugPag roda
      // embarcado. Devolve comando pro app local acionar o leitor.
      return { comando: 'ACIONAR_LEITOR_LOCAL', motivo: `PlugPag embarcado deve acionar o leitor da Moderninha ${serialNumber} localmente.`, valorLocal: valorTotal };
    },
    async consultarStatus(credentials, paymentId) {
      const resp = await httpRequest('GET', ENDPOINTS.pagbank.base + ENDPOINTS.pagbank.getOrder(paymentId), { Authorization: `Bearer ${credentials.token}` });
      if (resp.statusCode !== 200) throw new Error(`Falha ao consultar pedido ${paymentId} no PagBank (HTTP ${resp.statusCode})`);
      const charge = (resp.body.charges || [])[0];
      return { statusOficial: charge?.status, pago: charge?.status === 'PAID' };
    },
  },

  stone: {
    async testConnection() { throw new StoneNotHomologadoError(); },
    async criarPix() { throw new StoneNotHomologadoError(); },
    async pushParaTerminal() { throw new StoneNotHomologadoError(); },
    async consultarStatus() { throw new StoneNotHomologadoError(); },
  },
};

function getAdapter(provider) {
  const a = adapters[provider];
  if (!a) throw new ProviderNaoSuportadoError(provider);
  return a;
}

// ─────────────────────────────────────────────────────────────────────────
// 5. FUNÇÕES DE NEGÓCIO
// ─────────────────────────────────────────────────────────────────────────

async function testConnection(provider, credentials) {
  try {
    const r = await getAdapter(provider).testConnection(credentials);
    return { provider, ...r };
  } catch (err) {
    return { provider, conectado: false, motivo: err.message };
  }
}

async function processMesaPayment(provider, orderData, credentials, serialNumber, tipoPagamento, empresaId) {
  const { orderId, numeroMesa, valorTotal, itensPedido } = orderData;
  const adapter = getAdapter(provider);
  const resultado = { provider, orderId, numeroMesa, tipoPagamento };

  if (tipoPagamento === 'pix') {
    resultado.pix = await adapter.criarPix(credentials, valorTotal, orderId);
  } else if (tipoPagamento === 'cartao') {
    resultado.terminal = await adapter.pushParaTerminal(credentials, serialNumber, valorTotal, orderId);
  } else {
    throw new Error(`tipoPagamento inválido: '${tipoPagamento}'.`);
  }

  resultado.textoParaImprimirLocal = montarTextoConta(numeroMesa, itensPedido, valorTotal, orderId);

  await supabase.from('cobrancas_mesa').upsert({
    empresa_id: empresaId,
    order_id: String(orderId),
    provider,
    serial_number: serialNumber,
    numero_mesa: numeroMesa,
    itens_pedido: itensPedido,
    valor_total: valorTotal,
    tipo_pagamento: tipoPagamento,
    payment_id: resultado.pix?.paymentId || resultado.terminal?.paymentIntentId || resultado.terminal?.orderId || null,
    status: 'aguardando_confirmacao',
    atualizado_em: new Date().toISOString(),
  }, { onConflict: 'order_id,provider' });

  return resultado;
}

async function webhookReceiver(request, response) {
  try {
    const provider = request.params.provider;
    const paymentIdRecebido = request.body?.data?.id || request.body?.Payment?.PaymentId || request.body?.id;
    if (!provider || !paymentIdRecebido) return response.status(400).json({ erro: 'Webhook sem provider ou paymentId reconhecível.' });

    const { data: cobranca } = await supabase.from('cobrancas_mesa').select('*')
      .eq('provider', provider).eq('payment_id', String(paymentIdRecebido)).single();
    if (!cobranca) return response.status(200).json({ recebido: true, processado: false });

    const { data: maquina } = await supabase.from('maquininhas_empresa').select('*')
      .eq('empresa_id', cobranca.empresa_id).eq('provider', provider).eq('serial_number', cobranca.serial_number).single();
    if (!maquina) return response.status(200).json({ recebido: true, processado: false, motivo: 'Maquininha não cadastrada.' });

    // DOUBLE-CHECK obrigatório: nunca confia só no payload do webhook.
    const statusReal = await getAdapter(provider).consultarStatus(decifrarCredentials(maquina.credentials), paymentIdRecebido);

    if (!statusReal.pago) {
      await supabase.from('cobrancas_mesa').update({ status: 'nao_confirmado', status_oficial_adquirente: statusReal.statusOficial }).eq('id', cobranca.id);
      return response.status(200).json({ recebido: true, pago: false });
    }

    const imprimirCozinhaLocal = montarTextoCozinha(cobranca.numero_mesa, cobranca.itens_pedido || [], cobranca.order_id);

    const supabaseCliente = await getSupabaseDoCliente(cobranca.empresa_id);
    await supabaseCliente.from('pedidos_cozinha').update({ status_pagamento: 'pago', pago_em: new Date().toISOString() }).eq('id', cobranca.order_id);
    await supabase.from('cobrancas_mesa').update({
      status: 'pago_confirmado', status_oficial_adquirente: statusReal.statusOficial,
      texto_cozinha_pendente: imprimirCozinhaLocal, texto_cozinha_impresso: false,
    }).eq('id', cobranca.id);

    // Vai no corpo de resposta como pedido — mas quem lê essa resposta é a
    // ADQUIRENTE, não a maquininha (ver nota no topo do arquivo). A entrega
    // real pra maquininha acontece via GET /orders/:orderId/status abaixo.
    return response.status(200).json({ recebido: true, pago: true, orderId: cobranca.order_id, imprimirCozinhaLocal });

  } catch (err) {
    console.error('[Webhook]', err);
    return response.status(200).json({ recebido: true, processado: false, erroInterno: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────
// 6. ROTAS EXPRESS
// ─────────────────────────────────────────────────────────────────────────

function exigirEmpresaAutenticada(req, res, next) {
  const empresaId = req.headers['x-empresa-id'];
  if (!empresaId) return res.status(401).json({ erro: 'Empresa não autenticada (header x-empresa-id ausente).' });
  req.empresaId = empresaId;
  next();
}

// POST /api/v1/payments/test-connection  { provider, credentials, serialNumber }
router.post('/payments/test-connection', express.json(), exigirEmpresaAutenticada, async (req, res) => {
  const { provider, credentials, serialNumber } = req.body || {};
  if (!provider || !credentials || !serialNumber) {
    return res.status(400).json({ erro: 'Campos obrigatórios: provider, credentials, serialNumber.' });
  }

  const resultado = await testConnection(provider, credentials);
  const credentialsCifrado = cifrarCredentials(credentials);

  const { error } = await supabase.from('maquininhas_empresa').upsert({
    empresa_id: req.empresaId,
    provider,
    serial_number: serialNumber,
    credentials: credentialsCifrado,
    status_conexao: resultado.conectado ? 'conectado' : 'erro',
    ultimo_teste_em: new Date().toISOString(),
  }, { onConflict: 'empresa_id,provider,serial_number' });

  if (error) return res.status(500).json({ erro: 'Conexão testada, mas falhou ao salvar no Supabase.' });
  return res.status(resultado.conectado ? 200 : 422).json(resultado);
});

// POST /api/v1/clientes/config-supabase  { supabaseUrl, supabaseAnonKey }
// Chamado automaticamente pelo CookControl (não pelo dono do restaurante)
// pra registrar qual é o Supabase de verdade daquele cliente — assim o
// webhook sabe em qual banco marcar o pedido como "pago".
router.post('/clientes/config-supabase', express.json(), exigirEmpresaAutenticada, async (req, res) => {
  const { supabaseUrl, supabaseAnonKey } = req.body || {};
  if (!supabaseUrl || !supabaseAnonKey) {
    return res.status(400).json({ erro: 'Campos obrigatórios: supabaseUrl, supabaseAnonKey.' });
  }
  const { error } = await supabase.from('config_supabase_cliente').upsert({
    empresa_id: req.empresaId,
    supabase_url: supabaseUrl,
    supabase_anon_key: supabaseAnonKey,
    atualizado_em: new Date().toISOString(),
  }, { onConflict: 'empresa_id' });

  if (error) return res.status(500).json({ erro: 'Falha ao registrar o Supabase do cliente.' });
  return res.status(200).json({ registrado: true });
});
router.post('/payments/process', express.json(), exigirEmpresaAutenticada, async (req, res) => {
  const { provider, orderData, serialNumber, tipoPagamento } = req.body || {};
  if (!provider || !orderData?.orderId || !orderData?.numeroMesa || orderData?.valorTotal == null || !orderData?.itensPedido || !serialNumber || !tipoPagamento) {
    return res.status(400).json({ erro: 'Campos obrigatórios: provider, serialNumber, tipoPagamento, orderData{orderId,numeroMesa,valorTotal,itensPedido}.' });
  }

  const { data: maquina } = await supabase.from('maquininhas_empresa').select('*')
    .eq('empresa_id', req.empresaId).eq('provider', provider).eq('serial_number', serialNumber).single();

  if (!maquina) return res.status(404).json({ erro: `Maquininha ${provider}/${serialNumber} não cadastrada para esta empresa.` });
  if (maquina.status_conexao !== 'conectado') return res.status(422).json({ erro: `Conexão '${provider}' não validada. Rode o teste primeiro.` });

  try {
    const credentials = decifrarCredentials(maquina.credentials);
    const resultado = await processMesaPayment(provider, orderData, credentials, serialNumber, tipoPagamento, req.empresaId);
    return res.status(200).json(resultado);
  } catch (err) {
    return res.status(500).json({ erro: err.message });
  }
});

// POST /api/v1/webhooks/:provider — chamado pela adquirente
router.post('/webhooks/:provider', express.json(), webhookReceiver);

// GET /api/v1/orders/:orderId/status — a maquininha física consulta aqui
// pra saber quando imprimir a comanda da cozinha (idempotente: só entrega
// o texto uma vez).
router.get('/orders/:orderId/status', async (req, res) => {
  const { data: cobranca } = await supabase.from('cobrancas_mesa').select('*')
    .eq('order_id', req.params.orderId).order('atualizado_em', { ascending: false }).limit(1).single();
  if (!cobranca) return res.status(404).json({ erro: 'Pedido não encontrado.' });

  const resposta = {
    status: cobranca.status,
    pago: cobranca.status === 'pago_confirmado',
    imprimirCozinhaLocal: cobranca.status === 'pago_confirmado' && !cobranca.texto_cozinha_impresso ? cobranca.texto_cozinha_pendente : null,
  };
  if (resposta.imprimirCozinhaLocal) {
    await supabase.from('cobrancas_mesa').update({ texto_cozinha_impresso: true }).eq('id', cobranca.id);
  }
  return res.status(200).json(resposta);
});

module.exports = router;

/* ═══════════════════════════════════════════════════════════════════════
   SQL — rodar no Supabase SQL Editor ANTES de usar este arquivo
   ═══════════════════════════════════════════════════════════════════════

-- Cada maquininha física, de cada marca, vinculada à empresa dona dela.
CREATE TABLE IF NOT EXISTS maquininhas_empresa (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id       UUID NOT NULL,
  provider         TEXT NOT NULL CHECK (provider IN ('mercadopago','cielo','stone','pagbank')),
  serial_number    TEXT NOT NULL,
  credentials      JSONB NOT NULL,       -- { cifrado, iv, authtag } — nunca texto puro
  status_conexao   TEXT NOT NULL DEFAULT 'nao_configurado'
                    CHECK (status_conexao IN ('nao_configurado','testando','conectado','erro')),
  ultimo_teste_em  TIMESTAMPTZ,
  criado_em        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (empresa_id, provider, serial_number)
);

-- Cobrança de cada mesa, vinculando a maquininha física que cobrou.
CREATE TABLE IF NOT EXISTS cobrancas_mesa (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id               UUID NOT NULL,
  order_id                 TEXT NOT NULL,
  provider                 TEXT NOT NULL,
  serial_number            TEXT NOT NULL,
  numero_mesa              TEXT NOT NULL,
  itens_pedido             JSONB NOT NULL,
  valor_total              NUMERIC(10,2) NOT NULL,
  tipo_pagamento           TEXT NOT NULL CHECK (tipo_pagamento IN ('pix','cartao')),
  payment_id               TEXT,
  status                   TEXT NOT NULL DEFAULT 'aguardando_confirmacao'
                            CHECK (status IN ('aguardando_confirmacao','pago_confirmado','nao_confirmado')),
  status_oficial_adquirente TEXT,
  texto_cozinha_pendente   TEXT,
  texto_cozinha_impresso   BOOLEAN NOT NULL DEFAULT false,
  criado_em                TIMESTAMPTZ NOT NULL DEFAULT now(),
  atualizado_em            TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (order_id, provider)
);

CREATE INDEX IF NOT EXISTS idx_cobrancas_mesa_provider_paymentid ON cobrancas_mesa (provider, payment_id);
CREATE INDEX IF NOT EXISTS idx_cobrancas_mesa_order ON cobrancas_mesa (order_id);

ALTER TABLE maquininhas_empresa ENABLE ROW LEVEL SECURITY;
ALTER TABLE cobrancas_mesa ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS empresa_isolada_maquininhas ON maquininhas_empresa;
CREATE POLICY empresa_isolada_maquininhas ON maquininhas_empresa
  USING (empresa_id::text = auth.jwt() ->> 'empresa_id');

DROP POLICY IF EXISTS empresa_isolada_cobrancas_mesa ON cobrancas_mesa;
CREATE POLICY empresa_isolada_cobrancas_mesa ON cobrancas_mesa
  USING (empresa_id::text = auth.jwt() ->> 'empresa_id');

   ═══════════════════════════════════════════════════════════════════════ */
